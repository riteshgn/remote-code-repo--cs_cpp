#pragma once
///////////////////////////////////////////////////////////////////////
// TestPersistence.h - Implements all test cases for Persistence     //
// ver 1.1                                                           //
// Language:    C++, Visual Studio 2017                              //
// Application: NoSqlDb, CSE687 - Object Oriented Design             //
// Author:      Ritesh Nair (rgnair@syr.edu)                         //
///////////////////////////////////////////////////////////////////////
/*
* Package Operations:
* -------------------
* This file implements the test functors for testing Persistence

* Required Files:
* ---------------
* Persistence.h, Persistence.cpp
* XmlDocument.h, XmlDocument.cpp
* XmlElement.h, XmlElement.cpp
* DbTestHelper.h
*
* Maintenance History:
* --------------------
* ver 1.2 : 15 Apr 2018
* - Moved implementation into cpp file
* ver 1.0 : 08 Feb 2018
* - first release
*/
#ifndef TEST_PERSISTENCE_H
#define TEST_PERSISTENCE_H

#include "../TestCore/TestCore.h"

#include <iostream>

namespace NoSqlDbTests {
    /////////////////////////////////////////////////////////////////////
    // test functors
    // - Implements test cases to demonstrate the various requirements 
    //   on Persistence module
    class test8a : public TestCore::AbstractTest { 
    public:
        test8a(AbstractTest::TestTitle title) : AbstractTest(title) {  }
        virtual bool operator()(); 
    };
    class test8b : public TestCore::AbstractTest {
    public:
        test8b(AbstractTest::TestTitle title) : AbstractTest(title) {  }
        virtual bool operator()(); 
    };
    class test11a : public TestCore::AbstractTest {
    public:
        test11a(AbstractTest::TestTitle title) : AbstractTest(title) {  }
        virtual bool operator()();
    };
    class test11b : public TestCore::AbstractTest {
    public:
        test11b(AbstractTest::TestTitle title) : AbstractTest(title) {  }
        virtual bool operator()();
    };
}

#endif // !TEST_PERSISTENCE_H